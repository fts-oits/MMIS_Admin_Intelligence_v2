# MMIS Intelligence Design v4 — Admin Request Center

## What changed

The **Global Operations Dashboard** was updated directly, preserving its layout, styling and existing V3 intelligence additions. The fourth KPI card now reads **Requests Awaiting Action** and opens the prototype Request Center. A new **Requests Needing Attention** board sits **immediately below the four KPIs and above Rent & Payments**. Operational Exceptions remains separate and contains non-request alerts.

The Requests board includes Onboarding, Rental Applications, KYC Verification, Reconciliation Requests, Support Tickets and Contract Approvals. Its **All pending / Assigned to me / Past due** segments update category counts consistently. Selecting a category opens a filtered Request Center, rather than a misleading or unscoped placeholder.

Request Center offers search, type, Market, priority, status, assignee, submission-age and due/SLA filters; sorting; 10-row pagination; an accessible inspect action; a request-detail drawer; and filtered-sample CSV export. Action buttons are illustrative only and cannot change records.

The standalone HTML is fully self-contained and can be opened in a browser. The complete package also contains all seven previous design pages, 179 approved intelligence groups, related definitions and updated Global Dashboard source assets.

## Important rules

- All 47 request records (12 onboarding + 9 rental + 8 KYC + 6 reconciliation + 7 support + 5 Contract), eight overdue flags and 8 sample Markets are invented design data frozen as of November 10, 2026.
- MarketMaster is limited to Example Market A in the demo (15 matching requests). SuperAdmin can review all or selected Markets.
- **Requests** are unique actionable case/work-item IDs, not unique people. Separate KYC work items can be related to an onboarding case but may only count once each as independently actionable records. The genuine backend must authoritatively resolve cross-type IDs and avoid duplicates.
- Figures elsewhere in the older dashboard are also illustrative, not synchronized to the mock Request Center and not financial acceptance evidence.
- The prototype performs no real approval, KYC, reconciliation, assignment, financial posting or notifications. Production must enforce permissions, row-level Market scope, PII minimization and audit trails on the backend.

## PM review path

1. Open `START_HERE_V3.html` for the complete suite, or `MMIS_Admin_Dashboard_Request_Center_Standalone.html` for a one-file preview.
2. Review the fourth KPI card and six-category board placement.
3. Switch SuperAdmin (All Markets / Market A / Market B) and MarketMaster; compare counts and Market isolation.
4. Select `Assigned to me`, then `Past due`; inspect a category.
5. Click `Open Request Center`; filter by type, Market, urgency, SLA, assigned officer and search.
6. Click `Inspect` for the detail drawer and review evidence, assignment and timeline placeholders.
7. Export filtered CSV and confirm it is clearly labeled sample data.
8. Review desktop, 390px and 360px screenshots. Approve labels, information hierarchy and actions separately from backend contracts.

## Proposed live contracts (not implemented)

- `GET /api/admin/request-center/summary` scoped category counts, distinct actionable IDs, SLA figures and as-of metadata
- `GET /api/admin/request-center/requests` authorized offset-paginated worklist with search/filter/sort and exact total
- `GET /api/admin/request-center/requests/:reference` source-linked detail, evidence and event history
- `POST /api/admin/request-center/export` export entire filtered authorized cohort with stable reporting snapshot
- `POST /api/admin/request-center/requests/:reference/actions` guarded assignment/approval/escalation with versioning and audit

All endpoints are **proposed examples**, not claimed to exist in MMIS. Use safe adapters to the existing Vendor, Facility, KYC, Contract, billing/reconciliation and Support case services. Status semantics and SLA policy must be approved before a numeric card goes live.

## Files

- `MMIS_Admin_Dashboard_Request_Center_Standalone.html`: easiest PM preview, no server needed
- `01_Global_Dashboard/MMIS_Global_Operations_Admin_Prototype.html`: V3-integrated design, loads the `04_Intelligence_V3` CSS/JS assets
- `04_Intelligence_V3/requests-v4.css`, `requests-v4.js`: additive V4 component assets
- `05_Request_Center_V4/`: screenshots, QA report and review checklist
- `START_HERE_V3.html`: updated full-suite launcher

No GitHub branches, PRs or MMIS production records are modified by this package.
