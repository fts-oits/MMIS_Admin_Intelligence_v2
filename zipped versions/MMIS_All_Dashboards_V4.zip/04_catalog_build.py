from pathlib import Path
import json
root=Path('/mnt/data/mmis_intelligence_dev_v3/04_Intelligence_V3');root.mkdir(parents=True,exist_ok=True)
groups={
 'Vendor':[
 ('Identity, onboarding & compliance', '''V01|Registered Vendor accounts and status|P0|Vendor accounts by registration status
V02|Registration approvals and review time|P0|Vendor onboarding applications
V03|Invitation and account-claim progress|P1|Invitation records and claim history
V04|Email, phone and profile verification|P0|Contact verification worklist
V05|KYC status, expiry and review backlog|P0|KYC evidence and reviewer actions
V06|TIN and tax-compliance completeness|P1|Tax and compliance evidence
V07|Duplicates, imports and staged promotions|P0|Identity matching and import evidence
V08|Onboarding funnel, completion and delay|P1|Onboarding steps and completion times'''),
 ('Tenancy, Facilities & Contracts', '''V09|Assigned, unassigned and multi-Market Vendors|P0|Vendor to physical Facility relationships
V10|Vendors by Shop, Stall, Pitch, Cage and Lock-up|P0|Unit Type attribution and Vendor records
V11|Vendors by rent contract status|P0|RentContract and tenancy evidence
V12|Facility claims and conflicting assignments|P0|Allocation and claim decisions
V13|Contract acceptance and activation blockers|P0|Contract approval and Vendor acceptance
V14|Contract expiry and renewal windows|P1|Expiry calendar and Contract history
V15|Approved rental tariff and Contract overrides|P1|Applicable rental policy and rate history
V16|Tenure, multiple contracts and overlaps|P1|Tenant history and conflicts
V17|Termination, clearance and Facility release|P2|Facility-release cases'''),
 ('Rent, billing & payments', '''V18|Expected contracted rent by period and Unit Type|P0|Approved contract rate and period
V19|Issued rent invoices and billing coverage|P0|Billing runs and issued invoice records
V20|Received versus applied payments and collection rate|P0|Confirmed sources and allocations
V21|Rent still unpaid, due soon and overdue|P0|Eligible invoice obligations
V22|Invoice status: unpaid, partial, paid, void, held|P0|Invoice evidence by status
V23|Largest balances, debt concentration and distribution|P1|Ranked Vendor/invoice balances
V24|Collection rate by Market, Facility and classification|P1|Reconciled period-matched cohort
V25|Historical arrears and aging movements|P1|Invoice movements and recovery evidence
V26|Billing generation failures and duplicates|P0|Billing run and exception records
V27|Advance payments and Vendor credits|P0|Credit sources, consumption and coverage
V28|Unallocated payments, refunds and financial holds|P0|Source-to-invoice reconciliation
V29|Receivables recovery and promises to pay|P2|Recovery case evidence'''),
 ('Overdue rent & collection risk', '''V30|Vendors overdue 1–30, 31–60, 61–90, over 90 days|P0|Invoice-based exclusive aging
V31|Overdue value and invoices by aging bucket|P0|Overdue Vendor, Facility and invoice list
V32|Cumulative 30+, 60+ and 90+ exposure|P1|Cumulative aging, clearly labeled
V33|Repeat lateness and worsening overdue trend|P1|Historical aging trajectories
V34|Highest overdue balances and oldest invoices|P0|Ranked debt records
V35|Collection restrictions and approved notices|P1|Approved policy and decision evidence
V36|Reminder eligibility, dispatch and outcomes|P2|Notification audit and source invoices'''),
 ('Operations, stock & engagement', '''V37|Operational readiness and inactive businesses|P1|Eligibility and access readiness
V38|Product catalog coverage and listing quality|P1|Product records and classifications
V39|Low stock, stockouts and stale inventory|P1|Inventory ledger evidence
V40|Requisitions, bids and fulfillment|P1|Demand-to-delivery records
V41|Gate and Stock receiving exceptions|P1|Verified goods custody records
V42|Sales, baskets, growth and gross margins|P2|Verified POS and cost evidence only
V43|Vendor activity and engagement history|P2|Approved business-event logs
V44|Unread notices and failed communications|P2|Communication audit
V45|Support cases, complaints and resolution times|P2|Service-case history''')],
 'Facility':[
 ('Physical units & location', '''F01|Total rentable units and lifecycle statuses|P0|Canonical physical Facility register
F02|Units by Shop, Stall, Pitch, Cage and Lock-up|P0|Facility Type records
F03|Shop-backed units versus legacy standalone Stalls|P0|Companion/legacy reconciliation
F04|Units by Market, Level and Section|P0|Location and hierarchy
F05|Rentable area and unit-size distribution|P2|Measured dimensions where available
F06|Duplicate or unclassified physical records|P0|Registry exceptions'''),
 ('Occupancy & availability', '''F07|Occupied, vacant and reserved units|P0|Recorded registry status
F08|Occupancy by Market, Type, Level and Section|P0|Location-filtered Facility cohort
F09|Assigned, unassigned and conflicting units|P0|Unit-to-Vendor assignments
F10|Distinct assigned Vendors by Unit Type|P0|Vendor drilldown by same Facility population
F11|Allocation-ready, reserved and pending applications|P1|Rental applications and reservations
F12|Public listings and listing eligibility|P1|Public Shop listing records
F13|Long vacancies and turnover trends|P2|Historical occupancy events
F14|Inspected versus unverified physical occupancy|P2|Actual inspection evidence'''),
 ('Contract & claim integrity', '''F15|Active, missing, pending and expired Contracts|P0|Facility RentContract records
F16|Occupied units with missing or mismatched Contracts|P0|Shared tenancy reconciliation cases
F17|Facility claims and dispute statuses|P0|Claim review decisions
F18|Overlapping Contracts and tenant identity conflicts|P0|Contract timeline and exceptions
F19|Contract expiry and renewal calendar|P1|Expiring tenancy records
F20|Terminations and Facility release blockers|P1|Clearance and termination history
F21|Missing signed/accepted rental terms|P1|Contract document evidence'''),
 ('Rent & Unit Type financial performance', '''F22|Expected rent by Unit Type and location|P0|Approved rate and eligible contracts
F23|Rent billed by Unit Type and month|P0|Issued invoice attribution
F24|Payments applied to Facility invoices|P0|Confirmed allocations only
F25|Rent still unpaid by Unit Type and Facility|P0|Invoice-level remaining balance
F26|Overdue 1–30, 31–60, 61–90 and over 90|P0|Same-invoice Shop/Contract/Vendor scope
F27|Collection rates and averages by Unit Type|P1|Aligned billed and applied amounts
F28|Approved rental rate and override comparison|P1|Tariff/rental-policy evidence
F29|Expected versus billed and billing gaps|P1|Eligible liability and invoice issuance
F30|Held, duplicate and unreconciled financial amounts|P0|Invoice/payment/credit/source holds
F31|Rent by Level/Section and overdue hotspots|P1|Location-attributed invoice evidence
F32|Vacancy opportunity estimates|P2|Explicit tariff-based hypothetical scenario
F33|Renewal forecasts and rate-change projections|P2|Approved forecast assumptions'''),
 ('Facility operations & lifecycle', '''F34|Open maintenance and repair requests|P2|Work-order system if available
F35|Maintenance cost and repeat-failure units|P2|Costed repair evidence
F36|Condition, inspection and safety ratings|P2|Approved inspection observations
F37|Utilities and service interruptions|P2|Meter and service events
F38|QR/Token link quality and missing associations|P1|Facility-aware QR and token records
F39|Gate, delivery and Stock custody exceptions|P1|Goods-receipt handover records
F40|Accessibility and service complaints|P2|Facility service cases
F41|Missing Facility documents and ownership conflicts|P0|Document registry and identity evidence''')],
 'Supplier':[
 ('Registration & compliance', '''S01|Supplier accounts by registration status|P0|Global Supplier registry
S02|KYC: missing, pending, verified, rejected, expired|P0|Supplier qualification records
S03|TIN, tax and license compliance|P1|Verified compliance documentation
S04|Invitations and onboarding conversion|P1|Invitation and activation funnel
S05|Approved, restricted or blocked Suppliers|P1|Supplier authorization/eligibility
S06|Duplicate identities, TINs and imported Suppliers|P0|Supplier identity reconciliation
S07|Approval turnaround and expiry backlog|P1|KYC timestamps and decisions'''),
 ('Capabilities & market coverage', '''S08|Supplier business types and classifications|P0|Classification registry
S09|Products, categories, brands and capabilities|P1|Supplier product catalog
S10|Market eligibility and actual service participation|P1|Verified Market relationships, not registration
S11|Geographic and delivery coverage|P1|Verified service-area records
S12|No-coverage or single-source categories|P1|Authorized Supplier-to-demand matching
S13|Catalog availability, MOQ and quoted lead times|P1|Product offer terms
S14|Capacity and active order load|P2|Supplier capacity commitments'''),
 ('Requisitions & bidding', '''S15|Open requisitions, bid coverage and no-bid demand|P1|Vendor requisition queue
S16|Invited Supplier response and time|P1|Invitation and bid timestamps
S17|Bid submitted, rejected, accepted and withdrawn|P1|Bid lifecycle records
S18|Award rate and competitive success|P1|Award decisions, not inferred revenue
S19|Bids per requisition and single-bid awards|P1|Competitive sourcing evidence
S20|Comparable bid price spread and variance|P1|Normalized item/unit quotations
S21|Late responses and invalid quotations|P1|Bid validation worklist
S22|Demand by category, Market and due date|P1|Authorized procurement opportunities'''),
 ('Purchase orders & commitments', '''S23|POs by lifecycle status|P1|Approved PO records
S24|Approved PO value and undelivered commitments|P1|PO line items and fulfillment
S25|PO approvals and acknowledgments pending|P1|Order decision history
S26|Requisition-to-PO and award-to-PO conversion|P1|Linked document timestamps
S27|Delivery commitments due and overdue|P1|PO promised dates
S28|PO amendments and price/quantity changes|P2|Approved revision history
S29|Purchase frequency, repeat orders and concentration|P1|PO populations'''),
 ('Delivery, Gate & Stock', '''S30|Deliveries by dispatch, arrival and acceptance|P1|Delivery lifecycle evidence
S31|On-time delivery rate and late days|P1|Promised date versus verified receipt
S32|In-full delivery rate and quantity variance|P1|Ordered versus accepted lines
S33|On-Time In-Full (OTIF) by Supplier|P1|Eligible due PO lines and complete receipts
S34|Gate access and token verification exceptions|P1|Gate and QR/token events
S35|Gate accepted but not Stock verified|P0|Custody handover and receipt gaps
S36|Damage, rejection and shortages|P1|Goods acceptance/quality events
S37|Receiving time and recurring custody errors|P1|Verified gate-to-stock event timestamps
S38|Goods accepted but Vendor stock not reconciled|P0|Receipt versus inventory ledger
S39|Supplier returns and dispute resolution|P2|Approved returns workflow'''),
 ('Invoices, settlement & spend', '''S40|Approved PO, received, invoiced and paid value|P1|Linked PO, receipt, invoice and settlement
S41|Supplier invoices by approval status|P1|Accounts payable invoice records
S42|Amount payable, due soon and overdue|P1|Verified payable ledger
S43|Settlement pending, confirmed, failed or reversed|P1|Confirmed payment evidence
S44|Invoice, PO and goods receipt matching|P1|Three-way match exceptions
S45|Purchase spend by Market and category|P1|Accounting-approved spend basis
S46|Price variance and comparable savings|P1|Comparable item price evidence
S47|Tax and fiscal-document completeness|P1|Approved VAT and tax evidence
S48|Payment days, timing and discounts|P2|Payables settlement events
S49|Landed cost and category cost breakdown|P2|Delivery/tax/cost evidence'''),
 ('Performance & supplier risk', '''S50|Transparent Supplier quality, price and delivery score|P1|Weighted score with source and sample sizes
S51|Top and low-performing Suppliers by evidence|P1|Verifiable fulfillment and delivery records
S52|Single-source and Supplier concentration risk|P1|Approved PO/category participation
S53|Explainable high-risk Supplier worklist|P1|Repeated delay, quality and compliance issues
S54|Disputes, complaints and resolution rates|P2|Service and procurement cases
S55|Acknowledgments and communication outcomes|P2|Audited Supplier messages
S56|Sustainability and business credentials|P2|Verified qualification documents
S57|Supplier retention and historical activity|P2|Longitudinal procurement evidence''')]
}
items=[]
for domain,sections in groups.items():
 for category,block in sections:
  for row in block.splitlines():
   id,title,priority,drilldown=row.split('|')
   maturity=('Foundation' if (domain=='Vendor' and id in ['V01','V02','V04','V05','V09','V10','V11','V18','V19','V22','V27','V30']) or (domain=='Facility' and id in ['F01','F02','F03','F04','F07','F08','F09','F10','F15']) or (domain=='Supplier' and id in ['S01','S02','S06']) else 'Proposed capability' if priority=='P2' else 'New aggregation')
   items.append(dict(id=id,domain=domain,category=category,title=title,priority=priority,maturity=maturity,drilldown=drilldown))
from collections import Counter
counts=Counter(i['domain'] for i in items)
assert counts=={'Vendor':45,'Facility':41,'Supplier':57}, counts
cross="""C01|Approved Vendors without Facility assignments|P0|Approved Vendor vs physical Facility
C02|Occupied units without valid RentContracts|P0|Facility registry vs active Contract
C03|Contracted Vendors without generated rent invoices|P0|Tenancy obligations vs billing evidence
C04|Rent owed by Shop, Stall, Pitch, Cage and Lock-up|P0|Same invoice/Contract/Facility relationship
C05|Vendors with multiple unpaid Facilities|P0|Vendor debt by qualified Contract and unit
C06|High-rent units with persistent arrears|P1|Facility rate and invoice aging
C07|Vacant Facilities with verified pending demand|P1|Vacancy and approved rental applications
C08|Vendor stockouts and procurement demand|P1|Inventory alerts and requisition records
C09|Requisitions without qualifying Supplier bids|P1|Demand and Supplier eligibility
C10|Accepted orders with late Supplier delivery|P1|PO promise versus verified receipt
C11|Gate-verified goods lacking Stock receipt|P0|Gate and Stock custody chain
C12|Received goods missing Vendor inventory posting|P0|Goods receipt vs inventory ledger
C13|Suppliers with repeated rejected goods|P1|Inspection/receiving quality
C14|Vendor purchases awaiting approved settlement|P1|Vendor and Supplier PO/payable evidence
C15|Overdue rent receivables versus Supplier payables|P0|Separate AR/AP ledgers with no netting
C16|Markets depending on a single Supplier category|P1|Approved PO and category spend
C17|Supplier failures affecting multiple Vendors|P1|Delivery-quality and affected Vendors
C18|Unverified KYC linked to active transactions|P0|Identity compliance and audited activity
C19|Cross-Market Vendor/Facility/Contract identity conflicts|P0|Market-scoped assignment reconciliation
C20|Financial records requiring review|P0|Invoice, allocation, credit and refund source
C21|Missing rent fiscal/VAT evidence|P1|Invoice and approved fiscal status
C22|Public Shop listing conflicts with recorded occupancy|P0|Public listing and canonical occupancy
C23|Approved Vendors delayed in Contract activation|P1|Approval-to-tenancy completion funnel
C24|Market readiness from verified component evidence|P2|Vendor, Facility, Supplier, staff and Finance"""
staff="""M01|Assigned MarketMasters by Market|P0|Authorized manager assignment records
M02|Market coverage gaps and unassigned Markets|P0|Market and manager assignment
M03|Active and suspended staff accounts|P0|Role-aware staff identity records
M04|Gate staff per assigned Market or location|P0|Market-scoped Gate staff assignments
M05|Staff role and permission discrepancies|P0|RBAC scope and identity audit
M06|Gate versus Stock handover coverage|P1|Authorized duty assignments and custody events
M07|Shift coverage and attendance evidence|P2|Approved shift/check-in events
M08|Pending staff invitations and account claims|P1|Invitation and account enrollment
M09|Expiring staff permissions and assignments|P1|Authorization timeline
M10|Staff approvals and onboarding SLA|P1|Role activation history
M11|Staff action/audit backlog|P1|Authorized review and audit events
M12|Staff incident resolution and workload|P2|Approved cases, timestamps and assignment"""
for domain,category,block in [('Cross-domain','Operational convergence',cross),('Staff','Management and coverage',staff)]:
 for row in block.splitlines():
  id,title,priority,drilldown=row.split('|')
  items.append(dict(id=id,domain=domain,category=category,title=title,priority=priority,maturity=('Proposed capability' if priority=='P2' else 'New aggregation'),drilldown=drilldown))
assert len(items)==179,len(items)
out='window.MMIS_KPI_CATALOG_V3 = '+json.dumps(items,ensure_ascii=False,separators=(',',':'))+';\n'
(root/'kpi-catalog.js').write_text(out)
(root/'kpi-catalog.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
print('Saved',len(items),'groups',counts)
