# PM Review — Requests Awaiting Action / Request Center

- [ ] Fourth headline card clearly says **Requests Awaiting Action**, not a generic mix of all operational exceptions.
- [ ] Six category counts add up to the headline total in the same scope and selected queue tab.
- [ ] Request Center appears directly after headline cards and before financial reporting; operational alerts are separately grouped below.
- [ ] Category labels: Onboarding Requests, Rental Applications, KYC Verification, Reconciliation Requests, Support Tickets, Contract Approvals.
- [ ] SuperAdmin may filter by authorized Market; MarketMaster is restricted to assigned Market.
- [ ] **All pending / Assigned to me / Past due** tabs are clear and update the category breakdown.
- [ ] Click any category to see exactly the corresponding filtered queue.
- [ ] Filter controls cover request category, Market, priority, status, assignee, submission age, deadline/SLA and search.
- [ ] Table supports sorting, offset pagination, sample CSV export and a clear no-result state.
- [ ] Request inspection shows applicant, reference, linked entity, Market, assignee, status, due date, evidence and timeline.
- [ ] Action controls are not active until backend permissions, workflow policy and audit are complete.
- [ ] Count unique actionable cases, with related onboarding/KYC work items explicitly distinguished from unique people.
- [ ] Screen adapts to narrow mobile layouts without global horizontal scrolling.
- [ ] Main theme, header, card design, typography, contrasts and focus states preserve MMIS appearance.
- [ ] PM confirms presentation only; financial and server-side behavior require separate engineering UAT.
