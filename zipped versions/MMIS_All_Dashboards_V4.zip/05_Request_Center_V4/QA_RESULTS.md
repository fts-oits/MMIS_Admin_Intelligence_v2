# Request Center v4 — Local visual QA

- SuperAdmin_Global_Requests_Desktop: 47 cases, six categories = 47, no JS errors or page-wide overflow.
- SuperAdmin_Selected_Market_Requests_Desktop: 15 cases, six categories = 15, no JS errors or page-wide overflow.
- MarketMaster_Requests_Desktop: 15 cases, six categories = 15, no JS errors or page-wide overflow.
- SuperAdmin_Global_Requests_Mobile: 47 cases, six categories = 47, no JS errors or page-wide overflow.
- MarketMaster_Requests_Mobile: 15 cases, six categories = 15, no JS errors or page-wide overflow.

Also checked: 9 Rental Applications and 8 past-due cases under global scope; request drawer; MarketMaster assigned-Market isolation; board tabs; navigation from the fourth KPI and category cards. Checked in Chromium using isolated in-memory `page.set_content()`; this does not simulate authentication or backend APIs.
