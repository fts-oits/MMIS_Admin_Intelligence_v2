import asyncio,re,json
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parents[1]
assets=root/'04_Intelligence_V3'
css=(assets/'insights-v3.css').read_text()
cat=(assets/'kpi-catalog.js').read_text()
v3=(assets/'insights-v3.js').read_text().replace('const root=document.currentScript?.src||location.href;',"const root='https://preview.invalid/04_Intelligence_V3/insights-v3.js';")
files={
 'global':'01_Global_Dashboard/MMIS_Global_Operations_Admin_Prototype.html',
 'vendorfac':'02_Vendor_Facility/MMIS_Vendor_Facility_Interactive_Prototype.html',
 'expanded':'03_Expanded_Intelligence/MMIS_Expanded_Intelligence_Interactive_Prototype.html',
 'library':'04_Intelligence_V3/KPI_LIBRARY.html'
}
def content(key):
 s=(root/files[key]).read_text()
 s=re.sub(r'<link rel="stylesheet" href="[^" ]*insights-v3\.css"\s*>','',s)
 s=re.sub(r'<script defer src="[^" ]*(?:kpi-catalog|insights-v3)\.js"></script>','',s)
 s=s.replace('</head>',f'<style>{css}</style></head>',1)
 s=s.replace('</body>',f'<script>{cat}</script><script>{v3}</script></body>',1)
 return s
async def check(page,tag):
 x=await page.evaluate('''() => ({catalog:window.MMIS_KPI_CATALOG_V3?.length||0,hubs:document.querySelectorAll('.v3-hub').length,cards:document.querySelectorAll('.v3-insight-card').length,wide:document.documentElement.scrollWidth-innerWidth,visible:document.querySelectorAll('.v3-hub:not([hidden])').length})''')
 print(tag,json.dumps(x));assert x['catalog']==179 and x['hubs']>0,tag
 return x
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=__import__('shutil').which('chromium') or __import__('shutil').which('chromium-browser'),args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1340,'height':900},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(content('vendorfac'),wait_until='load')
  await page.wait_for_timeout(450)
  await check(page,'vendorfac')
  await page.locator('#page-facility .v3-hub').screenshot(path=str(assets/'Facility_V3_Insights_Desktop.png'),timeout=15000)
  await page.locator('#page-facility [data-v3-unit=STALL]').click()
  assert await page.locator('#unit').input_value()=='STALL'
  assert await page.locator('#aging').input_value()=='DAYS_61_90'
  assert 'active' in (await page.locator('#page-vendor').get_attribute('class') or '')
  print('Stall → 61–90-day Vendor selection: PASS')
  await page.locator('#page-vendor .v3-hub').screenshot(path=str(assets/'Vendor_V3_Insights_Desktop.png'),timeout=15000)
  await page.locator('#page-vendor .v3-insight-card button').first.click()
  assert await page.locator('#v3-modal').get_attribute('aria-hidden')=='false'
  await page.locator('#v3-modal .v3-close').click()
  await page.locator('#page-vendor .v3-search').fill('credit')
  result=await page.locator('#page-vendor .v3-count').inner_text()
  print('Vendor search credit',result)
  await page.close()
  page=await browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(content('vendorfac'),wait_until='load')
  await check(page,'vendorfac_mobile')
  await page.locator('#page-facility .v3-intro').screenshot(path=str(assets/'Facility_V3_Mobile_Intro.png'))
  await page.close()
  page=await browser.new_page(viewport={'width':1340,'height':900},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(content('global'),wait_until='load')
  await check(page,'global')
  await page.locator('#overview .v3-hub').screenshot(path=str(assets/'Global_V3_Insights_Desktop.png'))
  await page.close()
  page=await browser.new_page(viewport={'width':1340,'height':900},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(content('expanded'),wait_until='load')
  await check(page,'expanded')
  await page.locator('#supplier-admin .v3-hub').screenshot(path=str(assets/'Supplier_Admin_V3_Insights_Desktop.png'))
  await page.locator('#page').select_option('staff-admin')
  await page.locator('#staff-admin .v3-hub').screenshot(path=str(assets/'Staff_Admin_V3_Insights_Desktop.png'))
  await page.locator('#page').select_option('vendor-business')
  await page.locator('#account-state').select_option('pending')
  print('vendor pending hub hidden',await page.locator('#vendor-business .v3-hub').get_attribute('hidden'))
  assert await page.locator('#vendor-business .v3-hub').is_hidden()
  await page.locator('#account-state').select_option('approved')
  await page.locator('#vendor-business .v3-hub').screenshot(path=str(assets/'Vendor_Business_V3_Insights_Desktop.png'))
  await page.locator('#page').select_option('supplier-business')
  await page.locator('#supplier-business .v3-hub').screenshot(path=str(assets/'Supplier_Business_V3_Insights_Desktop.png'))
  await page.close()
  page=await browser.new_page(viewport={'width':1340,'height':900},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content(content('library'),wait_until='load')
  await check(page,'library')
  await page.locator('.v3-domain').select_option('Supplier')
  v=await page.locator('.v3-count').inner_text();print('Supplier library',v);assert v.startswith('57 of')
  await page.locator('.v3-domain').select_option('Cross-domain')
  v=await page.locator('.v3-count').inner_text();print('Cross-domain library',v);assert v.startswith('24 of')
  await page.locator('.v3-domain').select_option('')
  await page.locator('.v3-intro').screenshot(path=str(assets/'KPI_Library_V3_Intro.png'))
  await page.close()
  print('JS ERRORS',errors[:10]);assert not errors,errors[:10]
  await browser.close()
asyncio.run(main())
