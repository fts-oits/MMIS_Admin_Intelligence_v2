import asyncio,os,json
from pathlib import Path
from playwright.async_api import async_playwright
base=Path('/mnt/data/mmis_intelligence_dev_v3')
targets=[
('Global_Enhanced_Desktop','01_Global_Dashboard/MMIS_Global_Operations_Admin_Prototype.html',1365,900,'Global'),
('Vendor_Facility_Enhanced_Desktop','02_Vendor_Facility/MMIS_Vendor_Facility_Interactive_Prototype.html',1365,900,'Facility'),
('Supplier_Admin_Enhanced_Desktop','03_Expanded_Intelligence/MMIS_Expanded_Intelligence_Interactive_Prototype.html',1365,900,'Supplier'),
('KPI_Library_Desktop','04_Intelligence_V3/KPI_LIBRARY.html',1365,1000,'Library'),
('Vendor_Facility_Enhanced_Mobile','02_Vendor_Facility/MMIS_Vendor_Facility_Interactive_Prototype.html',390,844,'Mobile'),
]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
  for label,path,w,h,domain in targets:
   page=await browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   try:
    await page.goto("http://127.0.0.1:8765/"+path,wait_until='domcontentloaded',timeout=16000)
    await page.wait_for_timeout(750)
    status=await page.evaluate('''() => ({catalog:window.MMIS_KPI_CATALOG_V3?.length||0,hubs:document.querySelectorAll('.v3-hub').length, cards:document.querySelectorAll('.v3-insight-card').length,modal:!!document.getElementById('v3-modal'),width:document.documentElement.scrollWidth,viewport:innerWidth})''')
    await page.screenshot(path=str(base/'04_Intelligence_V3'/f'{label}.png'),full_page=True,timeout=16000)
    print(label,json.dumps({'status':status,'errors':errors[:5]}))
   except Exception as e:print(label,'ERROR',str(e)[:550])
   await page.close()
  await browser.close()
asyncio.run(main())
