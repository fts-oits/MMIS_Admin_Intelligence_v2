/* MMIS Request Center v4 — PM prototype only. No network, credentials, or live mutations. */
(function(){'use strict';
const $=id=>document.getElementById(id);
if(!$('requests-board') || !$('request-center')) return;
const sampleDate='2026-11-10';
const types=[
{id:'onboarding',name:'Onboarding Requests',short:'Onboarding',count:12,icon:'person',prefix:'ONB',entity:'Vendor onboarding',description:'Registration, invitation and approval applications'},
{id:'rental',name:'Rental Applications',short:'Rental applications',count:9,icon:'store',prefix:'RNT',entity:'Shop application',description:'Shop allocation, availability and tenancy applications'},
{id:'kyc',name:'KYC Verification',short:'KYC verification',count:8,icon:'shield',prefix:'KYC',entity:'KYC document review',description:'Identity and supporting documents awaiting validation'},
{id:'reconciliation',name:'Reconciliation Requests',short:'Reconciliation',count:6,icon:'scale',prefix:'REC',entity:'Payment reconciliation case',description:'Payment, allocation, billing or financial evidence review'},
{id:'support',name:'Support Tickets',short:'Support tickets',count:7,icon:'headset',prefix:'SUP',entity:'Support case',description:'Customer support and operations cases needing an officer'},
{id:'contracts',name:'Contract Approvals',short:'Contract approvals',count:5,icon:'file',prefix:'CTR',entity:'RentContract approval',description:'Contract acceptance, rate and renewal approvals'}
];
const icons={
person:'<circle cx="9" cy="8" r="3"/><path d="M3 19v-2a6 6 0 0 1 12 0v2M18 8v6m-3-3h6"/>',
store:'<path d="M3 9l2-5h14l2 5v3H3V9ZM5 12v8h14v-8M9 20v-5h6v5"/>',
shield:'<path d="M12 2l8 4v6c0 5-4 8-8 10-4-2-8-5-8-10V6l8-4Z"/><path d="m8.5 12 2.5 2.5 4.5-5"/>',
scale:'<path d="M12 3v18M4 6h16M7 6l-4 7h8L7 6Zm10 0-4 7h8l-4-7ZM8 21h8"/>',
headset:'<path d="M4 13V11a8 8 0 0 1 16 0v2M4 13h3v6H5a2 2 0 0 1-2-2v-2a2 2 0 0 1 1-2Zm16 0h-3v6h2a2 2 0 0 0 2-2v-2a2 2 0 0 0-1-2ZM18 19a6 6 0 0 1-6 3h-2"/>',
file:'<path d="M7 2h8l5 5v15H4V2h3Zm8 0v5h5M8 13h8M8 17h6"/>'
};
const svg=which=>`<svg viewBox="0 0 24 24" aria-hidden="true">${icons[which]}</svg>`;
const marketNames=Object.fromEntries(Array.from({length:8},(_,i)=>[String.fromCharCode(97+i),'Example Market '+String.fromCharCode(65+i)]));
const distribution=[...Array(15).fill('a'),...Array(10).fill('b'),...Array(8).fill('c'),...Array(6).fill('d'),...Array.from({length:8},(_,i)=>String.fromCharCode(101+(i%4)))];
const priorities=['urgent','high','normal'];
const statuses=['Awaiting review','Awaiting approval','Escalated'];
let counter=0, records=[];
let remaining=types.map(t=>t.count);
while(remaining.some(n=>n>0)){
 for(let t=0;t<types.length;t++){
  if(!remaining[t])continue;
  const type=types[t],i=counter++,market=distribution[i],n=type.count-remaining[t]+1;
  remaining[t]--;
  const overdue=i<8;
  const applicant=type.id==='support'?`Example Reporter ${i+1}`:type.id==='reconciliation'?`Example Payee ${i+1}`:`Example Applicant ${i+1}`;
  const daySubmitted=2+(i%8),dayDue=overdue?5+(i%5):12+(i%9);
  const assigned=i%6===0?'mine':i%7===0?'unassigned':'other';
  const assignee=assigned==='mine'?'Me · Admin reviewer':assigned==='unassigned'?'Unassigned':(type.id==='reconciliation'?'Finance officer':type.id==='support'?'Support officer':'Market reviewer');
  const priority=overdue?(i%2?'high':'urgent'):priorities[(i+1)%3];
  const status=overdue&&i%3===0?'Escalated':statuses[i%2];
  const entityRef=type.id==='rental'?`Shop S-${String(20+i).padStart(3,'0')}`:type.id==='contracts'?`Contract RC-${String(350+i)}`:type.id==='reconciliation'?`Payment PAY-${String(710+i)}`:type.id==='kyc'?`KYC case KY-${String(220+i)}`:type.id==='support'?`Ticket T-${String(550+i)}`:`Vendor V-${String(100+i)}`;
  records.push({id:`${type.prefix}-2026-${String(i+101).padStart(4,'0')}`,type:type.id,category:type.name,market,applicant,entityRef,created:`2026-11-${String(daySubmitted).padStart(2,'0')}`,due:`2026-11-${String(dayDue).padStart(2,'0')}`,priority,status,assigned,assignee,overdue,details:type.description,evidence:2+(i%4),parent:`Case CS-${String(410+i)}`});
 }
}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const role=$('role'),market=$('market');
let boardTab='all',page=1,openedId=null,lastFocus=null,toastTimeout;
const scoped=()=>records.filter(r=>role.value==='master'?r.market==='a':market.value==='all'||market.value===r.market);
const subset=()=>scoped().filter(r=>boardTab==='mine'?r.assigned==='mine':boardTab==='overdue'?r.overdue:true);
const pLabel=p=>p==='urgent'?'Urgent':p==='high'?'High':'Normal';
const categoryName=id=>types.find(t=>t.id===id)?.name||id;
const presentDate=s=>new Date(s+'T12:00:00Z').toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});
function updateBoard(){
 const all=scoped(),items=subset(),pastDue=all.filter(x=>x.overdue).length;
 const kpi=$('kpis')?.lastElementChild;
 if(kpi){kpi.removeAttribute('data-route');kpi.setAttribute('aria-label',`Open Request Center: ${all.length} requests awaiting action`);kpi.onclick=()=>openCenter();const n=kpi.querySelector('.k-number'),hint=kpi.querySelector('.k-note');if(n)n.textContent=all.length.toLocaleString();if(hint)hint.textContent=`${pastDue} past due · Open Request Center ↗`}
 $('req-tab-all').textContent=all.length;$('req-tab-mine').textContent=all.filter(x=>x.assigned==='mine').length;$('req-tab-overdue').textContent=pastDue;
 $('requests-past-due').textContent=`${pastDue} past due · sample`;
 $('requests-board-total').textContent=items.length;
 $('requests-scope-note').textContent=role.value==='master'?'Assigned Market only · Example Market A':market.value==='all'?'Across all authorized Markets (sample)':'Selected Market · '+marketNames[market.value];
 $('request-category-grid').innerHTML=types.map(t=>{const rows=items.filter(r=>r.type===t.id),late=rows.filter(r=>r.overdue).length;return `<button type="button" class="req-category" data-req-type="${esc(t.id)}" aria-label="Open ${esc(t.name)}, ${rows.length} requests"><span class="req-category-top"><span class="req-category-icon">${svg(t.icon)}</span><strong class="req-category-value">${rows.length}</strong></span><span class="req-category-name">${esc(t.name)}</span><span class="req-category-foot"><span>View matching requests →</span>${late?`<b>${late} past due</b>`:'<span>On time</span>'}</span></button>`}).join('');
 document.querySelectorAll('[data-req-board-tab]').forEach(b=>{const on=b.dataset.reqBoardTab===boardTab;b.classList.toggle('selected',on);b.setAttribute('aria-pressed',String(on))});
}
function form(){return {search:$('req-search').value.trim().toLowerCase(),type:$('req-category').value,market:$('req-market').value,priority:$('req-priority').value,status:$('req-status').value,assigned:$('req-assigned').value,age:$('req-age').value,sla:$('req-sla').value,sort:$('req-sort').value}}
function filtered(){const f=form();let rows=scoped().filter(r=>{
 if(f.type!=='all'&&r.type!==f.type)return false;
 if(f.market!=='all'&&r.market!==f.market)return false;
 if(f.priority!=='all'&&r.priority!==f.priority)return false;
 if(f.status!=='all'&&r.status!==f.status)return false;
 if(f.assigned!=='all'&&r.assigned!==f.assigned)return false;
 const age=10-Number(r.created.slice(-2));
 if(f.age==='0-7'&&age>7 || f.age==='8-14'&&(age<8||age>14) || f.age==='15+'&&age<15)return false;
 if(f.sla==='overdue'&&!r.overdue || f.sla==='on-time'&&r.overdue || f.sla==='soon'&&(r.overdue || Number(r.due.slice(-2))>13))return false;
 if(f.search && ![r.id,r.applicant,r.entityRef,r.parent,r.category,marketNames[r.market]].join(' ').toLowerCase().includes(f.search))return false;
 return true;
 });
 const pri={urgent:0,high:1,normal:2};
 rows.sort((a,b)=>f.sort==='due'?a.due.localeCompare(b.due):f.sort==='oldest'?a.created.localeCompare(b.created):f.sort==='recent'?b.created.localeCompare(a.created):pri[a.priority]-pri[b.priority]||a.due.localeCompare(b.due));
 return rows;
}
function setRequestMarketOptions(){const scopeMarket=role.value==='master'?'a':market.value;const opts=scopeMarket==='all'?Object.entries(marketNames):[[scopeMarket,marketNames[scopeMarket]]];const old=$('req-market').value;$('req-market').innerHTML=`<option value="all">${scopeMarket==='all'?'All authorized Markets':'Current Market'}</option>`+opts.map(([k,v])=>`<option value="${k}">${v}</option>`).join('');$('req-market').disabled=scopeMarket!=='all';if(scopeMarket==='all'&&opts.some(([k])=>k===old))$('req-market').value=old}
function renderCenter(){
 if($('request-center').hidden)return;
 setRequestMarketOptions();let rows=filtered(),all=scoped(),pageSize=10,numberOfPages=Math.max(1,Math.ceil(rows.length/pageSize));page=Math.min(Math.max(1,page),numberOfPages);
 $('req-center-stats').innerHTML=[['All awaiting action',all.length,'Distinct request records'],['Past due',all.filter(r=>r.overdue).length,'SLA missed · needs attention'],['Assigned to me',all.filter(r=>r.assigned==='mine').length,'Within authorized scope'],['Unassigned',all.filter(r=>r.assigned==='unassigned').length,'Need a responsible officer']].map(([title,n,note],i)=>`<article class="req-stat ${i===1?'warn':''}"><span>${title}</span><strong>${n}</strong><span>${note}</span></article>`).join('');
 $('req-count').textContent=`(${rows.length})`;$('req-result-subtitle').textContent=`${role.value==='master'?'Assigned Market only':'Authorized Market selection'} · Sample as-of ${presentDate(sampleDate)} · ${rows.length} matching records`;
 const current=rows.slice((page-1)*pageSize,page*pageSize);
 $('req-rows').innerHTML=current.length?current.map(r=>`<tr><td><span class="req-name">${esc(r.applicant)}</span><span class="req-sub">${esc(r.id)} · ${esc(r.entityRef)}</span></td><td>${esc(r.category)}</td><td>${esc(marketNames[r.market])}</td><td><span class="req-pill">${esc(r.status)}</span></td><td><span class="req-pill ${r.priority}">${pLabel(r.priority)}</span><span class="req-sub"><span class="${r.overdue?'req-pill overdue':''}">${r.overdue?'Past due · ': 'Due '}${presentDate(r.due)}</span></span></td><td>${esc(r.assignee)}</td><td><button class="req-open" data-req-open="${r.id}" type="button">Inspect →</button></td></tr>`).join(''):'<tr><td class="req-empty" colspan="7">No requests match these filters. Clear filters or select another category.</td></tr>';
 $('req-page-text').textContent=`Showing ${rows.length?((page-1)*pageSize+1):0}–${Math.min(page*pageSize,rows.length)} of ${rows.length} · Page ${page} of ${numberOfPages}`;
 $('req-prev').disabled=page<=1;$('req-next').disabled=page>=numberOfPages;
}
function clearRequestFilters(){for(const id of ['req-search'])$(id).value='';for(const id of ['req-category','req-market','req-priority','req-status','req-assigned','req-age','req-sla'])$(id).value='all';$('req-sort').value='priority';page=1;renderCenter()}
function openCenter(type='all',assigned='all',sla='all'){
 lastFocus=document.activeElement;
 document.body.classList.add('req-center-mode');$('request-center').hidden=false;
 clearRequestFilters();$('req-category').value=type;$('req-assigned').value=assigned;$('req-sla').value=sla;page=1;renderCenter();
 window.scrollTo({top:0,behavior:'instant'});
 const nav=$('req-nav');nav?.classList.add('active');nav?.setAttribute('aria-current','page');
 $('req-back').focus();
}
function closeCenter(){document.body.classList.remove('req-center-mode');$('request-center').hidden=true;$('req-nav')?.classList.remove('active');$('req-nav')?.removeAttribute('aria-current');window.scrollTo({top:0,behavior:'instant'});const x=lastFocus;lastFocus=null;if(x&&x.isConnected)x.focus()}
function detailContent(r){return `<div class="req-detail-summary"><h3>${esc(r.applicant)}</h3><p>${esc(r.details)}. This is a sample case, not an actual applicant.</p></div><dl class="req-detail-list"><div><dt>Request reference</dt><dd>${esc(r.id)}</dd></div><div><dt>Linked record</dt><dd>${esc(r.entityRef)}</dd></div><div><dt>Market</dt><dd>${esc(marketNames[r.market])}</dd></div><div><dt>Review status</dt><dd>${esc(r.status)}</dd></div><div><dt>Priority</dt><dd>${pLabel(r.priority)}</dd></div><div><dt>Assigned officer</dt><dd>${esc(r.assignee)}</dd></div><div><dt>Submitted</dt><dd>${presentDate(r.created)}</dd></div><div><dt>Decision deadline</dt><dd>${presentDate(r.due)}${r.overdue?' · Past due':''}</dd></div></dl><div class="req-detail-section"><h3>Evidence and history</h3><ul><li>${r.evidence} example supporting documents would be accessible only to authorized reviewers.</li><li>Application submitted: ${presentDate(r.created)} · ${esc(r.parent)}</li><li>Review task created and assigned: illustrative administrative workflow.</li><li>Decision, reassignment and escalation events require an immutable audit trail.</li></ul></div><div class="req-detail-section"><h3>What should happen when this is implemented?</h3><p>Open the authoritative case, verify linked records, view document versions, inspect previous decisions and apply the correct role-specific approval workflow. Every action must revalidate Market scope, request version, current status, recipient and permissions on the server.</p></div><div class="req-help">This mockup cannot approve applications, modify contracts, reconcile money, assign staff or send messages. Any action below shows a design preview only.</div>`}
function openDetail(id){const r=scoped().find(r=>r.id===id);if(!r)return;openedId=id;$('req-detail-heading').textContent=r.category;$('req-detail-content').innerHTML=detailContent(r);$('req-detail-backdrop').hidden=false;$('req-detail-close').focus();document.body.style.overflow='hidden'}
function closeDetail(){$('req-detail-backdrop').hidden=true;document.body.style.overflow='';openedId=null;$('req-search')?.focus()}
function toast(txt){clearTimeout(toastTimeout);const x=$('req-toast');x.textContent=txt;x.hidden=false;toastTimeout=setTimeout(()=>x.hidden=true,4000)}
function csvSafe(s){let v=String(s??'');if(/^[\s]*[=+\-@]/.test(v))v="'"+v;return '"'+v.replace(/"/g,'""')+'"'}
function exportCsv(){const r=filtered();const fields=[['Request ID','Category','Applicant (sample)','Market','Status','Priority','Submitted','Due','Past Due','Assigned To','Linked Record'],...r.map(x=>[x.id,x.category,x.applicant,marketNames[x.market],x.status,pLabel(x.priority),x.created,x.due,x.overdue?'Yes':'No',x.assignee,x.entityRef])];const csv='\uFEFF'+fields.map(row=>row.map(csvSafe).join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='MMIS_Sample_Requests_Filtered_V4.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200);toast(`Exported ${r.length} filtered SAMPLE requests. Production export must be backend-authorized.`)}
for(const t of types){const opt=document.createElement('option');opt.value=t.id;opt.textContent=t.name;$('req-category').append(opt)}
role.addEventListener('change',()=>{boardTab='all';closeDetailIfOpen();updateBoard();if(!$('request-center').hidden){page=1;renderCenter()}});
market.addEventListener('change',()=>{boardTab='all';closeDetailIfOpen();updateBoard();if(!$('request-center').hidden){page=1;renderCenter()}});
function closeDetailIfOpen(){if(!$('req-detail-backdrop').hidden)closeDetail()}
for(const id of ['req-search','req-category','req-market','req-priority','req-status','req-assigned','req-age','req-sla','req-sort'])$(id).addEventListener('input',()=>{page=1;renderCenter()});
document.addEventListener('click',e=>{
 const tab=e.target.closest('[data-req-board-tab]');if(tab){boardTab=tab.dataset.reqBoardTab;updateBoard();return}
 const cat=e.target.closest('[data-req-type]');if(cat){openCenter(cat.dataset.reqType,boardTab==='mine'?'mine':'all',boardTab==='overdue'?'overdue':'all');return}
 const row=e.target.closest('[data-req-open]');if(row){openDetail(row.dataset.reqOpen);return}
});
$('requests-view-all').addEventListener('click',()=>openCenter('all',boardTab==='mine'?'mine':'all',boardTab==='overdue'?'overdue':'all'));
$('requests-my-queue').addEventListener('click',()=>openCenter('all','mine'));
$('req-nav')?.addEventListener('click',e=>{e.preventDefault();openCenter()});
$('req-back').addEventListener('click',closeCenter);
$('req-clear').addEventListener('click',clearRequestFilters);
$('req-prev').addEventListener('click',()=>{page--;renderCenter()});$('req-next').addEventListener('click',()=>{page++;renderCenter()});
$('req-export').addEventListener('click',exportCsv);
$('req-detail-close').addEventListener('click',closeDetail);
$('req-detail-backdrop').addEventListener('click',e=>{if(e.target===$('req-detail-backdrop'))closeDetail()});
$('req-review-preview').addEventListener('click',()=>toast('Prototype: this would open the authenticated evidence and review workflow.'));
$('req-decision-preview').addEventListener('click',()=>toast('Prototype: approve / request information / reassign / escalate options require permission checks and audit.'));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('req-detail-backdrop').hidden)closeDetail()});
updateBoard();
window.MMISRequestCenterDemo={sampleRecordCount:records.length,counts:()=>({all:scoped().length,pastDue:scoped().filter(x=>x.overdue).length}),openCenter};
})();
