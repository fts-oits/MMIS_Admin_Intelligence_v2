# Fixed MMIS V4 offline preview

The previous extraction folder omitted assets referenced by the dashboard pages. The repaired package has all KPI and Request Center styles/scripts **embedded in each HTML page**, so it does not rely on sibling JS or CSS files.

Extract this ZIP and open `index.html` using Microsoft Edge or Chrome. No server/login/internet is needed.

The ChatGPT built-in preview may block JavaScript in downloaded HTML. In that case open the downloaded file in a full browser, or view the included static PNG.

All figures and workflows in the preview are illustrative and cannot be used as verified MMIS operational evidence.
